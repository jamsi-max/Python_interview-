from django.contrib import admin

from mainapp.models import Product

admin.site.register(Product)
